# UI Components Used
- [MUI Data Table](https://mui.com/material-ui/react-table/)
- [MUI Accordion Menu](https://mui.com/material-ui/react-accordion/)
- [MUI Modal](https://mui.com/material-ui/react-modal/)
- [MUI Card](https://mui.com/material-ui/react-card/)
- [Semantic UI Tabs](https://react.semantic-ui.com/modules/tab/)
- [Semantic UI Menu](https://react.semantic-ui.com/collections/menu/)

# Above and Beyond
- RIT colors, obviously
- ~~Seperated pages into different files for organization using React Router~~ nevermind, tried for so long to get this to work but RIT servers seemingly cannot handle it and i had to switch to a single page layout last minute :(
- Responsive design works on mobile widths